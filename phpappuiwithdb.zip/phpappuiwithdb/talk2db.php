<?php
header("Access-Control-Allow-Method: POST");
header("Access-Control-Allow-Method: GET");
header("Access-Control-Allow-Method: DELETE");


$vcapServices = json_decode(getenv('VCAP_SERVICES'), true);


//echo "hello World";

$returnString="Default Reponse";

try {
   //check if
   $db = pg_connect("host=".$vcapServices['postgresql10'][0]['credentials']['host']." port=".$vcapServices['postgresql10'][0]['credentials']['port']." dbname=".$vcapServices['postgresql10'][0]['credentials']['name']." user=".$vcapServices['postgresql10'][0]['credentials']['username']." password=".$vcapServices['postgresql10'][0]['credentials']['password']);
   if(!$db) {
      $returnString = "&emsp;IN API App --> Error : Unable to open database<br>";
   } else {
      $returnString = "&emsp;IN API App --> Opened database successfully<br>";
   }
   
   $sql =<<<EOF
         CREATE TABLE IF NOT EXISTS msgBrokerEventTable2
         (
         ID SERIAL PRIMARY KEY,
         eventPayload   TEXT    NOT NULL,
         created_on TIMESTAMP NOT NULL DEFAULT Now(),
         acknowledgement TEXT   NOT NULL 
         );
   EOF;
   
   $ret = pg_query($db, $sql);
   if(!$ret) {
      $returnString = $returnString . pg_last_error($db);
   } else {
      $returnString = $returnString . "&emsp;IN API App --> Table created successfully<br>";
   }
   
   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
       $returnString = $returnString . "&emsp;IN API App --> executing the POST  call<br>" ;
       // add the code to store MSGBroker event in DB
       //inserting data order
       $entityBody = file_get_contents('php://input');
       $input = strval(urldecode($entityBody)); 
       //echo $input ;
       //echo "<br>";
       error_log('the input is -' . $input);
       $sql = 'INSERT INTO msgBrokerEventTable2 (eventPayload,acknowledgement) VALUES (\''.$input.'\', \'no\')';
       //echo $sql ;
       if (!pg_connection_busy($db)) {
         pg_send_query($db, $sql);
       }
       $res1 = pg_get_result($db);
       if (!$res1) {
           echo "An error occurred while POST action to the DB.<br>";
           echo pg_result_error($res1)."<br>";
        }else {
            http_response_code(201);
            echo "DB Entry stored<br>";
        }
        
   }else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // We are a GET method
        //$returnString = $returnString . "&emsp;IN API App --> executing the GET call<br>" ;
        // add the code to GET MSGBroker event in DB
        $result = pg_query($db, "SELECT * FROM msgBrokerEventTable2");
        if (!$result) {
           echo "An error occurred while getting the table from DB.<br>";
           echo pg_result_error($result)."<br>";
        }else {
             while ($row = pg_fetch_row($result)) {
                http_response_code(200);
                //echo "Event: ". $row[0]  ." EventPayload: ".$row[1]." createOn: ".$row[2];
                //echo "<tr><td>". $row["name"] ."</td><td> ". $row["email"] ."</td><td> ". $row["segment"] ."</td><td>  ". $row["purpose"]." </td><td>". $row["Status"] ."</td> </tr>" ;
                echo "<tr><td>".$row[0]."</td><td>". $row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td></tr>" ;
                //echo "<br>";
             }
        }
   } else if ($_SERVER['REQUEST_METHOD'] === 'DELETE'){
       $result = pg_query($db, "TRUNCATE msgBrokerEventTable2 RESTART IDENTITY");
       if (!$result) {
           echo "An error occurred while Deleting the table from DB.<br>";
           echo pg_result_error($result)."<br>";
        } else {
            http_response_code(204);
            echo "Event Deleted<br>";
        }
   }
   pg_close($db); 
   $returnString = $returnString . "&emsp;IN API App --> Execution ends in API app<br>";

 }catch (customException $e) {
   echo $e->errorMessage();
 }



?>
<?php
define("gatewayURL", "https://gateway.eu1-int.mindsphere.io");
$respnseCode = "default";
//echo "Welcome to the Mindsphere - <br><br>";
$targetURL=urldecode(trim((htmlspecialchars($_GET['targetURL']))));
$operator=urldecode(trim((htmlspecialchars($_GET['operator']))));
$clientId = urldecode(trim((htmlspecialchars($_GET['clientId']))));
//$clientId= $_ENV['clientId'];
$clientsecret = urldecode(trim((htmlspecialchars($_GET['clientsecret']))));
//$clientsecret = $_ENV['clientsecret'];
$apiURL=urldecode(trim((htmlspecialchars($_GET['apiURL']))));
$data=strval(stripslashes(urldecode(trim($_GET['inputBody']))));

$subscriptonAction ="";
//$data1 = '{"grant_type": "client_credentials","appName": "myapiapp","appVersion": "v1.0.0","hostTenant": "tide517","userTenant": "tide517"}';

//echo "This is not working -".$data;
//echo "<br>This is working -".$data1 ."<br>";

$headers = array('Content-Type:application/json' ,'X-SPACE-AUTH-KEY:Bearer '.base64_encode($clientId.":".$clientsecret));

//getting the token
$token =  json_decode(CallAPI('POST', gatewayURL .'/api/technicaltokenmanager/v3/oauth/token', $data , $headers));
//echo $token->access_token;
//echo "<br>".$respnseCode."<br>";
if ($respnseCode == "200"){
   $responseText ="The Token is fetched successfully using API app credential. \n";                  
                    
}
$headers = array('Content-Type:application/json' ,'Authorization:Bearer '. $token->access_token);
$data = '{"uri":"'.gatewayURL . $apiURL .'"}';
if ($operator == 'PUT') {
     $subscriptonAction = "PUT";
}elseif($operator =='DELETE') {
      $subscriptonAction = "DELETE";              
}

//getting the subscription
$responseText =$responseText."\nThe response from the subscription call is -\n \n" . strval(CallAPI($subscriptonAction,gatewayURL . $targetURL , $data , $headers));;
//echo "<br>".$respnseCode."<br>";
//$responseText ="The response Code is -" . $responseText ;
$responseText =$responseText."\n \n\n The response code from the subscription call is - ".$respnseCode;

echo $responseText;
return $responseText;


//echo json_encode($_ENV);
function CallAPI($method, $url, $data, $headers) {
    //echo $data." - is a data<br>";
    global $respnseCode;

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_ENCODING, true);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FRESH_CONNECT, TRUE);
    curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    
    switch ($method) {
        case "GET":
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
            break;
        case "POST":
            curl_setopt($curl, CURLOPT_POSTFIELDS,$data);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            break;
        case "PUT":
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
            break;
        case "DELETE":
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE"); 
            break;
    }
    $response = curl_exec($curl);
    // Check the HTTP Status code
    $respnseCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    //echo curl_exec($curl)." - This is CURL Error<br>";
    //echo $response." - this is response <br>";
    return $response;
    curl_close($curl);
    die;
    
}

?>

<?php

define("gatewayURL", "https://gateway.eu1.mindsphere.io");
//echo "Welcome to the tenant -->> <br><br>";
//session_start();


// calling API to get bearer Token 
//$api ="/api/technicaltokenmanager/v3/oauth/token";
//$data = '{"grant_type": "client_credentials","appName": "renukeshappui","appVersion": "v1.0","hostTenant": "tpde512","userTenant": "tpde512"}';
//$headers = array('Content-Type:application/json' ,'X-SPACE-AUTH-KEY: Bearer dHBkZTUxMi1yZW51a2VzaGFwcHVpLXYxLjA6djVlUnRnU3RBWWtuRTAxTFpaQ0Q3MENqQnljQ0Y0NkF2Znp1cFhSRHNKcg==');
//$token = json_decode(CallAPI('POST', gatewayURL . "/" .'api/technicaltokenmanager/v3/oauth/token', $data, $headers));
//echo $token->access_token;
//$headers = array('Content-Type:application/json' ,'Authorization: Bearer '.$token->access_token);
//$rootAsset=json_decode(CallAPI('GET',gatewayURL . "/" . 'api/assetmanagement/v3/assets/root', $data, $headers));
//echo "Name of the Root Asset is - " .$rootAsset->name;

foreach (getallheaders() as $name => $value) {
  //echo "$name: $value<br>";
  if ($name == 'X-Forwarded-Host') {
    //echo "found Host <br>";
    $UI_Host = $value;
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <title>Mindsphere Database Interaction</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="./jquery.js"></script>
  <script src="./search.js"></script>
  <script src="./bootstrap.min.js"></script>
  <link rel="stylesheet" href="./bootstrap.min.css">

  <script>
    /* get the cookie based on input */
    function getCookie(input) {
      var cookies = document.cookie.split(';');
      for (var i = 0; i < cookies.length; i++) {
        var name = cookies[i].split('=')[0].toLowerCase().trim();
        var value = cookies[i].split('=')[1].toLowerCase().trim();
        if (name === input.toLowerCase()) {
          return value;
          console.log('The value of the cookie -' + input + ' is -' + value);
        } else if (value === input) {
          return name;
        }
      }
      return "";
    };


    function deleteTable() {
      //alert("are you suer you want to delete Table");
      var accessKey = prompt("Are you sure you want to delete the table ?\nAll the entires will be permanantly deleted.\n\nif yes then please enter the code word.", "");
      if (accessKey == "jlaw") {
        //alert("deleting the data base");
        //const xsrfToken = getCookie('XSRF-TOKEN');
        //alert(xsrfToken);
        //alert(document.cookie);

        //delete the table from postgres services
        $.ajax({
          type: "DELETE",
          headers: {
            'X-XSRF-TOKEN': getCookie('xsrf-token')
          },
          //str.substring(str.indexOf("XSRF-TOKEN=")+11);
          //url: "http://localhost:8080/festo/backend/",
          url: "talk2db.php",
          dataType: "json",
          async: true,
          success: function(response) {
            console.log("सर्वर ने रिस्पॉन्स धाडला ");
            console.log(response);
            var tempArray = JSON.parse(response);
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
          }
        });


      }
    }



    function fetchEvents() {
      //var tbodyRef = document.getElementById('navaTable').getElementsByTagName('myTable')[0];
      $.ajax({
        type: "GET",
        headers: {
          'X-XSRF-TOKEN': getCookie('xsrf-token')
        },
        //url: "http://localhost:8080/festo/backend/",
        url: "talk2db.php",
        dataType: "html",
        async: true,
        success: function(response) {
          console.log("सर्वर ने रिस्पॉन्स धाडला ");
          //console.log(response);
          //var tempArray = JSON.parse(response);
          var rowCount = document.getElementById("navaTable").rows.length;
          for (var x = rowCount - 1; x > 0; x--) {
            document.getElementById("navaTable").deleteRow(x);
          }
          $('#navaTable').append(response)
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.log(textStatus, errorThrown);
        }
      });
    }

    function AddDBEntry() {
      var entry = document.getElementById("AddDBEntry").value;

      $.ajax({
        url: "talk2db.php",
        type: "POST",
        headers: {
          'X-XSRF-TOKEN': getCookie('xsrf-token')
        },
        //url: "http://localhost:8080/festo/backend/",
        dataType: "json",
        async: true,
        'data': entry,
        success: function(response) {
          console.log("सर्वर ने रिस्पॉन्स धाडला ");
          //console.log(response);
          //var tempArray = JSON.parse(response);
          alert(response);
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.log(textStatus, errorThrown);
        }
      });
    }
  </script>
  <style>
    #navaTable,
    td {
      border: 2px solid black;
      border-collapse: collapse;
      text-align: center;
      padding: 8px;
    }

    th {
      border: 2px solid black;
      border-collapse: collapse;
      text-align: center;
      padding: 8px;
    }

    h1,
    h2,
    h3 {
      display: inline;
    }

    td,
    tr {
      border: none;
    }
  </style>
</head>

<body>

  <br><br>
  <div class="container-fluid" text-align="left">
    <h1>Mindsphere Cloud Foundry Database Interaction</h1>
    <br><br>
    <p>&#128555;wanted to get hands on Mindsphere CF Database ?</p>
    <p>Wait No more ! jsut post and get from Mindpshere Postgres db.</p>
    <p></p><br>


    <ul class="nav nav-tabs">
      <li class="active"><a data-toggle="tab" href="#About">
          <h2>About</h2>
        </a></li>
      <li><a data-toggle="tab" href="#db">
          <h2>Databse Interaction</h2>
        </a></li>
      <li><a data-toggle="tab" href="#headersEnvVariabels">
          <h2>Headers</h2>
        </a></li>
    </ul>

    <div class="tab-content">

      <!-- 
    ***********************************************************************************************************************************************************************
    <p>code for showing events.</p> 
    ***********************************************************************************************************************************************************************
    -->
      <div id="db" class="tab-pane fade">
        <br>
        <h3>Mindsphere Databse Interaction - </h3><br><br>
        <hr>
        <h4>Delete the table - <button type="button" onclick="deleteTable()">Delete The Table!</button> </h4>
        <br>
        <hr>
        <label for="fname">
          <h4>Add DB entry : - </h4>
        </label><input type="text" id="AddDBEntry" name="AddDBEntry" size="80" value='{"First":"First Entry in Dev tenant in First version of app"}'>&nbsp;&nbsp;<button type="button" onclick="AddDBEntry()">Add DB Entries</button>
        <br>
        <hr>
        <h4>Fetch the DB entries - <button type="button" onclick="fetchEvents()">Fetch Entries</button></h4<br>
          <input class="form-control" id="myInput" type="text" placeholder="Search in table..">
          <table id="navaTable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Index</th>
                <th>DB Entry</th>
                <th>Created</th>
                <th>Acknowledged</th>
              </tr>
            </thead>
            <tbody id="myTable">
            </tbody>
          </table>
      </div>
      <div id="About" class="tab-pane  in active"><br><br>
        This is for the Core to Third party Notification usecase<br><br>
        The page for dev cockpit team --> <a href="https://confluence.mindsphere-tools.siemens.cloud/display/SD/FESTO+%3A+Use+case"> Link </a><br><br>
        The page for Event Management team --> <a href="https://confluence.mindsphere-tools.siemens.cloud/display/IoT/Event+Management+%3A+Subscription+Based+Event+Notification"> Link </a><br><br>
        The page for IOT TS team --> <a href="https://confluence.mindsphere-tools.siemens.cloud/display/MDSPARCH/IoT+Data+Ingest+Notifications"> Link </a><br><br>
        <?php
        //echo "The client ID is -> ".getenv('MDSP_KEY_STORE_CLIENT_ID') ."<br>";
        //echo "The client Secret is -> ".getenv('MDSP_KEY_STORE_CLIENT_SECRET')."<br>";

        ?>

      </div>
      <div id="headersEnvVariabels" class="tab-pane"><br><br>
        This dispalays all the ENV variables and headers avaialble<br><br>
        <?php
        //echo "The client ID is -> ".$_ENV['MDSP_KEY_STORE_CLIENT_ID'] ."<br>";
        //echo "The client Secret is -> ".$_ENV['MDSP_KEY_STORE_CLIENT_SECRET']."<br>";
        echo "<br><br>The Env varables are  Are<br><br>";
        while (list($var, $value) = each(getenv())) {
          echo "$var => $value <br>";
        }
        echo "<br><br>The headers Are<br><br>";
        foreach (getallheaders() as $name => $value) {
          echo "$name: $value <br>";
        }
        echo "<br> The HTTP Authorizatoin for the app is <br>";
        $token = $_SERVER['HTTP_AUTHORIZATION'];
        echo "<h1></h1>\n";
        echo "<p>";
        if ($token == '') {
          echo "No Auth Token";
        } else {
          echo $token;
        }
        echo "</p>"
        ?>
      </div>
    </div>
  </div>








</body>

</html>